# POCO F7 Smooth Zoom — LSPosed

Target:
- Camera package: `com.android.camera`
- Camera version: `6.7.000070.0`
- Device target: POCO F7
- HyperOS: 3.0.301.0

## GitHub Actions build

The project is configured for GitHub Actions with:
- JDK 17 (Temurin)
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- `chmod +x gradlew` before build
- `./gradlew --no-daemon clean assembleDebug`
- Debug APK uploaded as a workflow artifact

The workflow also generates the Gradle wrapper on the runner, so the repository
can build even if `gradle/wrapper/gradle-wrapper.jar` was not committed.

## Local build

If Gradle 8.7 is installed:

```bash
gradle wrapper --gradle-version 8.7 --distribution-type bin
chmod +x gradlew
./gradlew --no-daemon clean assembleDebug
```

## LSPosed

1. Install the generated APK.
2. Enable the module in LSPosed.
3. Scope it to `com.android.camera`.
4. Force-stop Camera or reboot.

The current source retains the proven pinch-to-zoom smoothing hook. The camera
button zoom UI / configurable max zoom can be added on top of this base without
changing the Gradle/CI setup.
