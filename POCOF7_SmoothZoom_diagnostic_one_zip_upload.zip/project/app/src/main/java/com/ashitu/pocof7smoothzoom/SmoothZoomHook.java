package com.ashitu.pocof7smoothzoom;

import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Diagnostic build for POCO F7 Camera 6.7.000070.0.
 *
 * Keeps the known-good pinch hook, but does NOT change zoom values.
 * It logs runtime fields/methods around k9.k and y0() so we can locate
 * the real maximum-zoom gate before implementing an unlock.
 */
public final class SmoothZoomHook implements IXposedHookLoadPackage {
    private static final String TAG = "POCOF7SmoothZoom";

    private static final ThreadLocal<Object> ACTIVE_SCALE = new ThreadLocal<>();

    // Avoid dumping the same object repeatedly.
    private static final Set<Object> DUMPED =
            Collections.newSetFromMap(new WeakHashMap<Object, Boolean>());

    // Avoid logging every y0() call. Log a few representative target values.
    private static final Map<Object, Integer> Y0_LOG_COUNT =
            Collections.synchronizedMap(new WeakHashMap<Object, Integer>());

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam)
            throws Throwable {

        if (!"com.android.camera".equals(lpparam.packageName)) {
            return;
        }

        try {
            final ClassLoader cl = lpparam.classLoader;
            final Class<?> zoomManager = Class.forName("k9.k", false, cl);
            final Class<?> scaleEvent = Class.forName("L8.i", false, cl);

            log("DIAGNOSTIC START: k9.k / L8.i found");

            // Mark the synchronous call stack as a pinch update.
            XposedHelpers.findAndHookMethod(
                    zoomManager,
                    "onScale",
                    scaleEvent,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            ACTIVE_SCALE.set(param.thisObject);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            ACTIVE_SCALE.remove();
                        }
                    });

            log("HOOKED: k9.k.onScale(L8.i)");

            // IMPORTANT: no onScaleEnd hook. That method does not exist on this build.
            // We only use the existing time gap in the final implementation.

            // y0(float,int) is the known central zoom-target path.
            XposedHelpers.findAndHookMethod(
                    zoomManager,
                    "y0",
                    float.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Object self = param.thisObject;

                            // First y0 call gives us the live instance and its state.
                            dumpOnce(self, zoomManager);

                            float target = ((Float) param.args[0]).floatValue();
                            int arg1 = ((Integer) param.args[1]).intValue();

                            int count = getCount(self);
                            if (count < 12) {
                                log("y0 call #" + (count + 1)
                                        + " target=" + target
                                        + " arg1=" + arg1
                                        + " activeScale=" + (ACTIVE_SCALE.get() == self));
                                setCount(self, count + 1);
                            }

                            // Diagnostic only: NEVER modify param.args.
                        }
                    });

            log("HOOKED: k9.k.y0(float,int)");
            log("HOOK SUCCESS: diagnostic build active; zoom values are untouched");

        } catch (Throwable t) {
            log("HOOK FAILED: " + Log.getStackTraceString(t));
        }
    }

    private static int getCount(Object obj) {
        Integer n = Y0_LOG_COUNT.get(obj);
        return n == null ? 0 : n.intValue();
    }

    private static void setCount(Object obj, int n) {
        Y0_LOG_COUNT.put(obj, Integer.valueOf(n));
    }

    private static void dumpOnce(Object obj, Class<?> clazz) {
        synchronized (DUMPED) {
            if (DUMPED.contains(obj)) {
                return;
            }
            DUMPED.add(obj);
        }

        log("========== k9.k RUNTIME DUMP ==========");
        log("class=" + clazz.getName());
        log("super=" + (clazz.getSuperclass() == null ? "null" : clazz.getSuperclass().getName()));

        Class<?>[] interfaces = clazz.getInterfaces();
        for (Class<?> i : interfaces) {
            log("interface=" + i.getName());
        }

        // Fields: names/types plus safe primitive/String/enum values.
        for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                String name = f.getName();
                String type = f.getType().getName();
                String lower = (name + " " + type).toLowerCase();

                if (lower.contains("zoom")
                        || lower.contains("ratio")
                        || lower.contains("max")
                        || lower.contains("range")
                        || lower.contains("scale")) {
                    String value = "<unreadable>";
                    try {
                        f.setAccessible(true);
                        if (!Modifier.isStatic(f.getModifiers())) {
                            Object v = f.get(obj);
                            if (v == null
                                    || v instanceof Number
                                    || v instanceof Boolean
                                    || v instanceof Character
                                    || v instanceof String
                                    || v.getClass().isEnum()) {
                                value = String.valueOf(v);
                            } else {
                                value = "<" + v.getClass().getName() + ">";
                            }
                        } else {
                            Object v = f.get(null);
                            value = String.valueOf(v);
                        }
                    } catch (Throwable ignored) {
                    }
                    log("FIELD " + c.getName() + "." + name
                            + " : " + type + " = " + value);
                }
            }
        }

        // Methods whose names/signatures suggest zoom/range/max handling.
        for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                String sig = methodSignature(m);
                String lower = sig.toLowerCase();
                if (lower.contains("zoom")
                        || lower.contains("ratio")
                        || lower.contains("max")
                        || lower.contains("range")
                        || lower.contains("scale")) {
                    log("METHOD " + c.getName() + "." + sig);
                }
            }
        }

        log("========== END RUNTIME DUMP ==========");
    }

    private static String methodSignature(Method m) {
        StringBuilder sb = new StringBuilder();
        sb.append(m.getName()).append('(');
        Class<?>[] p = m.getParameterTypes();
        for (int i = 0; i < p.length; i++) {
            if (i != 0) sb.append(',');
            sb.append(p[i].getName());
        }
        sb.append(')').append(':').append(m.getReturnType().getName());
        return sb.toString();
    }

    private static void log(String msg) {
        try {
            XposedBridge.log(TAG + ": " + msg);
        } catch (Throwable ignored) {
            Log.d(TAG, msg);
        }
    }
}
